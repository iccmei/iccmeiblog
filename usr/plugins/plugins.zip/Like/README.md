## 插件说明 ##
####typecho点赞like插件，调用<?php Like_Plugin::theLike(); ?>即可
####详细介绍：http://www.phoneshuo.com/PHP/typecho-like-plugin.html