<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>
<?php
/**
* 附件页
*
* 如果要显示附件页删除本模板即可。
*/
?>
<?php header("HTTP/1.1 404 Not Found"); ?>
<?php getOnline();?>